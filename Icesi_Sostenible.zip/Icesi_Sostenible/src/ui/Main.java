package ui;

/*
 * Contrato del sistema de área de Sostenibilidad Ambiental
 * Descripción: Sistema que permite a usuarios con distintos roles realizar diversas operaciones
 * para gestionar proyectos, evidencias, puntos de interés, y realizar simulaciones.
 * Registrar Usuarios:
 * - Investigadores, recolectores de información y visitantes.
 * Gestionar Proyectos:
 * - Registrar, modificar y borrar proyectos.
 * Gestionar Evidencias:
 * - Registrar, modificar y borrar evidencias.
 * Gestionar Puntos de Interés:
 * - Registrar, modificar y borrar puntos de interés.
 * Objetos de Prueba:
 * - Generar objetos con valores predefinidos en el sistema para cada tipo de usuario, proyecto y reseña.
 * Consultar la información detallada de un pilar y el listado de proyectos asociados.
 * Consultar la información detallada de un proyecto, cantidad de evidencias de tipo reseña
 * y cantidad de evidencias de otro tipo.
 * Simular el acceso de cada tipo de usuario con sus funcionalidades específicas:
 * Usuario Visitante:
 * - Dado un pilar y un proyecto, consultar el mapa general de puntos de interés asociados
 *   (se deben visualizar en el mapa las evidencias según su símbolo).
 * - Consultar a partir de la posición en el mapa la información detallada de una evidencia.
 * - Registrar comentarios a un punto de interés.
 * Usuario Recolector de Información:
 * - Registrar una reseña como evidencia a un proyecto.
 * - Todas las funcionalidades del usuario Visitante.
 * Usuario Investigador:
 * - Consultar la información detallada de un proyecto y el listado de evidencias asociadas.
 * - Registrar y modificar un proyecto (ver requerimiento 2).
 * - Registrar y modificar una evidencia (ver requerimiento 3).
 * - Revisar y cambiar de estado una reseña.
 * - Todas las funcionalidades de los usuarios Visitante y Recolector de Información.
 */

import java.text.ParseException;
import java.util.Scanner;
import model.Controller;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner scanner = new Scanner(System.in);
        Controller controller = new Controller();

        while (true) {
            System.out.println("Por favor, selecciona una opción:");
            System.out.println("1. Registrar Usuario");
            System.out.println("2. Ingrese al Área de Sostenibilidad Ambiental");
            System.out.println("3. Generar Objetos de Prueba");
            System.out.println("4. Consultar Información de un Pilar y sus Proyectos Asociados");
            System.out.println("5. Consultar Información de un Proyecto y sus Evidencias");
            System.out.println("6. Simulador");
            System.out.println("7. Salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el tipo de usuario (1. Investigador, 2. Recolector, 3. Visitante):");
                    int tipoUsuario = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Ingrese el nombre de usuario:");
                    String nombreUsuario = scanner.nextLine();

                    System.out.println("Ingrese la contraseña:");
                    String contrasena = scanner.nextLine();

                    if (tipoUsuario == 1) {
                        System.out.println("Ingrese el nombre del Investigador:");
                        String nombreInvestigador = scanner.nextLine();

                        System.out.println("Ingrese el correo del Investigador:");
                        String correoInvestigador = scanner.nextLine();

                        System.out.println("Ingrese el teléfono del Investigador:");
                        String telefonoInvestigador = scanner.nextLine();

                        System.out.println("Ingrese el área del Investigador:");
                        String areaInvestigador = scanner.nextLine();

                        System.out.println("Ingrese el cargo del Investigador:");
                        String cargoInvestigador = scanner.nextLine();

                        if (controller.registrarInvestigador(nombreUsuario, contrasena, nombreInvestigador, correoInvestigador, telefonoInvestigador, areaInvestigador, cargoInvestigador)) {
                            System.out.println("Investigador registrado con éxito.");
                        } else {
                            System.out.println("Hubo un error al registrar el investigador. Por favor, inténtelo de nuevo.");
                        }
                    } else if (tipoUsuario == 2) {
                        System.out.println("Ingrese el nombre del Recolector:");
                        String nombreRecolector = scanner.nextLine();

                        System.out.println("Ingrese el correo del Recolector:");
                        String correoRecolector = scanner.nextLine();

                        System.out.println("Ingrese el teléfono del Recolector:");
                        String telefonoRecolector = scanner.nextLine();

                        if (controller.registrarRecolector(nombreUsuario, contrasena, nombreRecolector, correoRecolector, telefonoRecolector)) {
                            System.out.println("Recolector registrado con éxito.");
                        } else {
                            System.out.println("Hubo un error al registrar el recolector. Por favor, inténtelo de nuevo.");
                        }
                    } else if (tipoUsuario == 3) {
                        if (controller.registrarVisitante(nombreUsuario, contrasena)) {
                            System.out.println("Visitante registrado con éxito.");
                        } else {
                            System.out.println("Hubo un error al registrar el visitante. Por favor, inténtelo de nuevo.");
                        }
                    } else {
                        System.out.println("Tipo de usuario no válido.");
                    }
                    break;
                case 2:
                    System.out.println("Ingrese al Área de Sostenibilidad Ambiental");
                    scanner.nextLine();

                    System.out.println("Ingrese el nombre de usuario:");
                    String nombreUsuarioEncontrar = scanner.nextLine();

                    System.out.println("Ingrese la contraseña:");
                    String contrasenaEncontrar = scanner.nextLine();

                    boolean autenticado = controller.autenticarUsuario(nombreUsuarioEncontrar, contrasenaEncontrar);

                    if (autenticado) {
                        String tipoUsuarioEncontrado = controller.obtenerTipoUsuario(nombreUsuarioEncontrar);

                        if (tipoUsuarioEncontrado != null) {
                            switch (tipoUsuarioEncontrado) {
                                case "Visitante":

                                    System.out.println("Menú para Visitante:");
                                    System.out.println("1. Consultar Puntos de Interés");
                                    System.out.println("2. Consultar Información de Proyectos");
                                    System.out.println("3. Consultar Información de Evidencias relacionadas con un Punto de Interés");
                                    System.out.println("4. Visualizar Detalles de un Punto de Interés");
                                    System.out.println("5. Hacer Comentarios en un Punto de Interés");
                                    System.out.println("6. Volver al Menú Principal");

                                    int opcionVisitante = scanner.nextInt();
                                    scanner.nextLine();

                                    switch (opcionVisitante) {
                                        case 1:
                                            controller.mostrarListaPuntosDeInteres();
                                            break;
                                        case 2:
                                            controller.mostrarListaProyectos();
                                            break;
                                        case 3:
                                            System.out.println("Ingrese el nombre del Punto de Interés:");
                                            String nombrePuntoInteres = scanner.nextLine();
                                            controller.mostrarEvidenciasRelacionadasConPunto(nombrePuntoInteres);
                                            break;
                                        case 4:
                                            System.out.println("Ingrese el nombre del Punto de Interés:");
                                            String nombrePuntoDetalle = scanner.nextLine();
                                            controller.mostrarDetallesPuntoDeInteres(nombrePuntoDetalle);
                                            break;
                                        case 5:
                                            System.out.println("Ingrese el nombre del Punto de Interés:");
                                            String nombrePuntoComentario = scanner.nextLine();
                                            System.out.println("Ingrese su comentario:");
                                            String comentario = scanner.nextLine();
                                            controller.registrarComentarioEnPunto(nombrePuntoComentario, comentario);
                                            break;
                                        case 6:
                                            System.out.println("Saliendo del menú de Visitante. ¡Hasta luego!");
                                            break;
                                        default:
                                            System.out.println("Opción no válida.");
                                            break;
                                    }
                                    break;
                                case "Recolector":
                                    System.out.println("Menú para Recolector:");
                                    System.out.println("1. Registrar Reseña");
                                    System.out.println("2. Volver al Menú Principal");

                                    int opcionRecolector = scanner.nextInt();
                                    scanner.nextLine();

                                    switch (opcionRecolector) {
                                        case 1:
                                            System.out.println("Ingrese el nombre de la reseña:");
                                            String nombreResena = scanner.nextLine();

                                            System.out.println("Ingrese la descripción de la reseña:");
                                            String descripcionResena = scanner.nextLine();

                                            System.out.println("Ingrese el nombre del proyecto al que desea asociar la reseña:");
                                            String nombreProyectoAsociado = scanner.nextLine();

                                            boolean resenaRegistrada = controller.registrarResena(nombreResena, descripcionResena, nombreProyectoAsociado);

                                            if (resenaRegistrada) {
                                                System.out.println("Reseña registrada correctamente. Pendiente de aprobación por el Investigador.");
                                            } else {
                                                System.out.println("Hubo un error al registrar la reseña. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 2:
                                            System.out.println("Saliendo del menú de Recolector. ¡Hasta luego!");
                                            break;
                                        default:
                                            System.out.println("Opción no válida.");
                                            break;
                                    }
                                    break;
                                case "Investigador":
                                    System.out.println("Menú para Investigador:");
                                    System.out.println("1. Crear Proyecto");
                                    System.out.println("2. Modificar Proyecto");
                                    System.out.println("3. Eliminar Proyecto");
                                    System.out.println("4. Crear Evidencia");
                                    System.out.println("5. Modificar Evidencia");
                                    System.out.println("6. Eliminar Evidencia");
                                    System.out.println("7. Registrar un punto de interes");
                                    System.out.println("8. Modificar punto de interes");
                                    System.out.println("9. Eliminar punto de interes");
                                    System.out.println("10. Aprobar/Rechazar Reseñas en Estado de Espera");
                                    System.out.println("11. Acceder a Información Detallada de Proyectos");
                                    System.out.println("12. Acceder a Información Detallada de las Evidencias");
                                    System.out.println("13. Volver al Menú Principal");

                                    int opcionInvestigador = scanner.nextInt();
                                    scanner.nextLine();

                                    switch (opcionInvestigador) {
                                        case 1:
                                            System.out.println("Ingrese el nombre del nuevo proyecto:");
                                            String nombreNuevoProyecto = scanner.nextLine();

                                            System.out.println("Ingrese a qué pilar pertenece el proyecto:");
                                            System.out.println("(1. Biodiversidad, 2. Gestion del recurso hídrico, 3. Gestion integral de residuos solidos, 4. Energia ");
                                            int numeroPilar = Integer.parseInt(scanner.nextLine());

                                            System.out.println("¿Es un proyecto activo? (Sí/No):");
                                            boolean proyectoActivo = scanner.nextLine().equalsIgnoreCase("Sí");

                                            System.out.println("Ingrese el ID del proyecto:");
                                            String idProyecto = scanner.nextLine();

                                            System.out.println("Ingrese la descripción del proyecto:");
                                            String descripcionProyecto = scanner.nextLine();

                                            System.out.println("Ingrese la fecha de inicio del proyecto (Formato: dd/mm/yyyy):");
                                            String fechaInicioProyecto = scanner.nextLine();

                                            System.out.println("Ingrese la fecha de fin del proyecto (Formato: dd/mm/yyyy):");
                                            String fechaFinProyecto = scanner.nextLine();

                                            boolean proyectoCreado = controller.registrarProyecto(
                                                    idProyecto, nombreNuevoProyecto, descripcionProyecto,
                                                    fechaInicioProyecto, fechaFinProyecto, String.valueOf(proyectoActivo), numeroPilar
                                            );

                                            if (proyectoCreado) {
                                                System.out.println("Nuevo proyecto creado con éxito.");
                                            } else {
                                                System.out.println("Hubo un error al crear el proyecto. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 2:
                                            System.out.println("¿Qué desea modificar en el proyecto?");
                                            System.out.println("1. Nombre del Proyecto");
                                            System.out.println("2. Descripción del Proyecto");
                                            System.out.println("3. Fechas del Proyecto");
                                            System.out.println("4. Estado del Proyecto");
                                            System.out.println("5. Volver al Menú Principal");

                                            int opcionModificarProyecto = scanner.nextInt();
                                            scanner.nextLine();

                                            switch (opcionModificarProyecto) {
                                                case 1:
                                                    System.out.println("Ingrese el nombre del proyecto que desea modificar:");
                                                    String nombreProyectoModificar = scanner.nextLine();
                                                    System.out.println("Ingrese el nuevo nombre del proyecto:");
                                                    String nuevoNombreProyecto = scanner.nextLine();
                                                    boolean nombreModificado = controller.modificarNombreProyecto(nombreProyectoModificar, nuevoNombreProyecto);

                                                    if (nombreModificado) {
                                                        System.out.println("Nombre del proyecto modificado correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar el nombre del proyecto. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 2:
                                                    System.out.println("Ingrese el nombre del proyecto que desea modificar:");
                                                    String nombreProyectoModificarDesc = scanner.nextLine();
                                                    System.out.println("Ingrese la nueva descripción del proyecto:");
                                                    String nuevaDescripcionProyecto = scanner.nextLine();
                                                    boolean descripcionModificada = controller.modificarDescripcionProyecto(nombreProyectoModificarDesc, nuevaDescripcionProyecto);

                                                    if (descripcionModificada) {
                                                        System.out.println("Descripción del proyecto modificada correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar la descripción del proyecto. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 3:
                                                    System.out.println("¿Qué fechas del proyecto desea modificar?");
                                                    System.out.println("1. Fecha de Inicio");
                                                    System.out.println("2. Fecha de Fin");
                                                    System.out.println("3. Volver al Menú Principal");

                                                    int opcionModificarFechas = scanner.nextInt();
                                                    scanner.nextLine();

                                                    switch (opcionModificarFechas) {
                                                        case 1:
                                                            System.out.println("Ingrese el nombre del proyecto que desea modificar:");
                                                            String nombreProyectoModificarFechaInicio = scanner.nextLine();
                                                            System.out.println("Ingrese la nueva fecha de inicio del proyecto (Formato: dd/mm/yyyy):");
                                                            String nuevaFechaInicio = scanner.nextLine();
                                                            boolean fechaInicioModificada = controller.modificarFechaInicioProyecto(nombreProyectoModificarFechaInicio, nuevaFechaInicio);

                                                            if (fechaInicioModificada) {
                                                                System.out.println("Fecha de inicio del proyecto modificada correctamente.");
                                                            } else {
                                                                System.out.println("Hubo un error al modificar la fecha de inicio del proyecto. Por favor, inténtelo de nuevo.");
                                                            }
                                                            break;
                                                        case 2:
                                                            System.out.println("Ingrese el nombre del proyecto que desea modificar:");
                                                            String nombreProyectoModificarFechaFin = scanner.nextLine();
                                                            System.out.println("Ingrese la nueva fecha de fin del proyecto (Formato: dd/mm/yyyy):");
                                                            String nuevaFechaFin = scanner.nextLine();
                                                            boolean fechaFinModificada = controller.modificarFechaFinProyecto(nombreProyectoModificarFechaFin, nuevaFechaFin);

                                                            if (fechaFinModificada) {
                                                                System.out.println("Fecha de fin del proyecto modificada correctamente.");
                                                            } else {
                                                                System.out.println("Hubo un error al modificar la fecha de fin del proyecto. Por favor, inténtelo de nuevo.");
                                                            }
                                                            break;
                                                        case 3:
                                                            System.out.println("Volviendo al Menú Principal.");
                                                            break;
                                                        default:
                                                            System.out.println("Opción no válida.");
                                                            break;
                                                    }
                                                    break;
                                                case 4:
                                                    System.out.println("¿Qué estado del proyecto desea modificar?");
                                                    System.out.println("1. Activar Proyecto");
                                                    System.out.println("2. Desactivar Proyecto");
                                                    System.out.println("3. Volver al Menú Principal");

                                                    int opcionModificarEstado = scanner.nextInt();
                                                    scanner.nextLine();

                                                    switch (opcionModificarEstado) {
                                                        case 1:
                                                            System.out.println("Ingrese el nombre del proyecto que desea activar:");
                                                            String nombreProyectoActivar = scanner.nextLine();
                                                            boolean proyectoActivado = controller.activarProyecto(nombreProyectoActivar);

                                                            if (proyectoActivado) {
                                                                System.out.println("Proyecto activado correctamente.");
                                                            } else {
                                                                System.out.println("Hubo un error al activar el proyecto. Por favor, inténtelo de nuevo.");
                                                            }
                                                            break;
                                                        case 2:
                                                            System.out.println("Ingrese el nombre del proyecto que desea desactivar:");
                                                            String nombreProyectoDesactivar = scanner.nextLine();
                                                            boolean proyectoDesactivado = controller.desactivarProyecto(nombreProyectoDesactivar);

                                                            if (proyectoDesactivado) {
                                                                System.out.println("Proyecto desactivado correctamente.");
                                                            } else {
                                                                System.out.println("Hubo un error al desactivar el proyecto. Por favor, inténtelo de nuevo.");
                                                            }
                                                            break;
                                                        case 3:
                                                            System.out.println("Volviendo al Menú Principal.");
                                                            break;
                                                        default:
                                                            System.out.println("Opción no válida.");
                                                            break;
                                                    }
                                                    break;
                                                case 5:
                                                    System.out.println("Volviendo al Menú Principal.");
                                                    break;
                                                default:
                                                    System.out.println("Opción no válida.");
                                                    break;
                                            }
                                            break;
                                        case 3:
                                            System.out.println("Ingrese el nombre del proyecto que desea eliminar:");
                                            String nombreProyectoEliminar = scanner.nextLine();

                                            boolean proyectoEliminado = controller.eliminarProyecto(nombreProyectoEliminar);

                                            if (proyectoEliminado) {
                                                System.out.println("Proyecto eliminado correctamente.");
                                            } else {
                                                System.out.println("Hubo un error al eliminar el proyecto. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 4:
                                            System.out.println("Ingrese el nombre de la nueva evidencia:");
                                            String nombreNuevaEvidencia = scanner.nextLine();

                                            System.out.println("Ingrese a qué proyecto pertenece la evidencia:");
                                            String proyectoEvidencia = scanner.nextLine();

                                            System.out.println("Ingrese el tipo de evidencia (audio, video, imágenes, texto o informes de resultados):");
                                            String tipoEvidencia = scanner.nextLine();

                                            System.out.println("¿Contiene un punto de interés? (Sí/No):");
                                            boolean tienePuntoInteres = scanner.nextLine().equalsIgnoreCase("Sí");

                                            System.out.println("Ingrese la URL de la evidencia:");
                                            String urlEvidencia = scanner.nextLine();

                                            System.out.println("Ingrese una descripción detallada de la evidencia:");
                                            String descripcionDetallada = scanner.nextLine();

                                            System.out.println("Ingrese la fecha de registro de la evidencia (Formato: dd/mm/yyyy):");
                                            String fechaRegistroEvidencia = scanner.nextLine();

                                            boolean evidenciaCreada = controller.registrarEvidencia(
                                                    nombreNuevaEvidencia, proyectoEvidencia, tipoEvidencia,
                                                    tienePuntoInteres, urlEvidencia, descripcionDetallada,
                                                    fechaRegistroEvidencia
                                            );

                                            if (evidenciaCreada) {
                                                System.out.println("Nueva evidencia creada con éxito.");
                                            } else {
                                                System.out.println("Hubo un error al crear la evidencia. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 5:
                                            System.out.println("Ingrese el nombre de la evidencia que desea modificar:");
                                            String nombreEvidenciaModificar = scanner.nextLine();

                                            System.out.println("¿Qué aspecto de la evidencia desea modificar?");
                                            System.out.println("1. Nombre Descriptivo");
                                            System.out.println("2. Tipo de Evidencia");
                                            System.out.println("3. URL");
                                            System.out.println("4. Descripción Detallada");
                                            System.out.println("5. Volver al Menú Principal");

                                            int opcionModificarEvidencia = scanner.nextInt();
                                            scanner.nextLine();

                                            switch (opcionModificarEvidencia) {
                                                case 1:
                                                    System.out.println("Ingrese el nuevo nombre descriptivo de la evidencia:");
                                                    String nuevoNombreDescriptivo = scanner.nextLine();
                                                    boolean nombreDescriptivoModificado = controller.modificarNombreDescriptivoEvidencia(nombreEvidenciaModificar, nuevoNombreDescriptivo);

                                                    if (nombreDescriptivoModificado) {
                                                        System.out.println("Nombre descriptivo de la evidencia modificado correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar el nombre descriptivo de la evidencia. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 2:
                                                    System.out.println("Ingrese el nuevo tipo de evidencia:");
                                                    String nuevoTipoEvidencia = scanner.nextLine();
                                                    boolean tipoEvidenciaModificado = controller.modificarTipoEvidencia(nombreEvidenciaModificar, nuevoTipoEvidencia);

                                                    if (tipoEvidenciaModificado) {
                                                        System.out.println("Tipo de evidencia modificado correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar el tipo de evidencia. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 3:
                                                    System.out.println("Ingrese la nueva URL de la evidencia:");
                                                    String nuevaURL = scanner.nextLine();
                                                    boolean URLModificada = controller.modificarURLEvidencia(nombreEvidenciaModificar, nuevaURL);

                                                    if (URLModificada) {
                                                        System.out.println("URL de la evidencia modificada correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar la URL de la evidencia. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 4:
                                                    System.out.println("Ingrese la nueva descripción detallada de la evidencia:");
                                                    String nuevaDescripcionDetallada = scanner.nextLine();
                                                    boolean descripcionDetalladaModificada = controller.modificarDescripcionDetalladaEvidencia(nombreEvidenciaModificar, nuevaDescripcionDetallada);

                                                    if (descripcionDetalladaModificada) {
                                                        System.out.println("Descripción detallada de la evidencia modificada correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar la descripción detallada de la evidencia. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 5:
                                                    System.out.println("Volviendo al Menú Principal.");
                                                    break;
                                                default:
                                                    System.out.println("Opción no válida.");
                                                    break;
                                            }
                                            break;
                                        case 6:
                                            System.out.println("Ingrese el nombre de la evidencia que desea eliminar:");
                                            String nombreEvidenciaEliminar = scanner.nextLine();

                                            boolean evidenciaEliminada = controller.eliminarEvidencia(nombreEvidenciaEliminar);

                                            if (evidenciaEliminada) {
                                                System.out.println("Evidencia eliminada correctamente.");
                                            } else {
                                                System.out.println("Hubo un error al eliminar la evidencia. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 7:
                                            System.out.println("Ingrese el nombre de la evidencia a la cual desea agregar un punto de interés:");
                                            String nombreEvidenciaAgregarPunto = scanner.nextLine();

                                            System.out.println("Ingrese el nombre del punto de interés:");
                                            String nombrePuntoInteres = scanner.nextLine();

                                            int coordenadaX = controller.generarCoordenadaAleatoria();
                                            int coordenadaY = controller.generarCoordenadaAleatoria();

                                            String contenidoCodigoUnico = controller.generarCodigoUnico();

                                            boolean puntoAgregado = controller.agregarPuntoDeInteresAEvidencia(nombreEvidenciaAgregarPunto, nombrePuntoInteres, coordenadaX, coordenadaY, contenidoCodigoUnico);

                                            if (puntoAgregado) {
                                                System.out.println("Punto de interés '" + nombrePuntoInteres + "' agregado correctamente a la evidencia.");
                                            } else {
                                                System.out.println("Hubo un error al agregar el punto de interés. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 8:
                                            System.out.println("Ingrese el nombre de la evidencia a la cual desea modificar un punto de interés:");
                                            String nombreEvidenciaModificarPunto = scanner.nextLine();

                                            System.out.println("Ingrese el nombre del punto de interés que desea modificar:");
                                            String nombrePuntoModificar = scanner.nextLine();

                                            System.out.println("Seleccione la propiedad que desea modificar:");
                                            System.out.println("1. Coordenada X");
                                            System.out.println("2. Coordenada Y");
                                            System.out.println("3. Contenido del Código Único");
                                            int opcion2 = scanner.nextInt();
                                            scanner.nextLine();

                                            switch (opcion2) {
                                                case 1:
                                                    System.out.println("Ingrese la nueva coordenada X del punto de interés:");
                                                    double nuevaCoordenadaX = scanner.nextDouble();
                                                    boolean coordXModificada = controller.modificarCoordenadaXDePuntoDeInteres(
                                                            nombreEvidenciaModificarPunto, nombrePuntoModificar, nuevaCoordenadaX
                                                    );
                                                    if (coordXModificada) {
                                                        System.out.println("Coordenada X modificada correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar la coordenada X del punto de interés. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 2:
                                                    System.out.println("Ingrese la nueva coordenada Y del punto de interés:");
                                                    double nuevaCoordenadaY = scanner.nextDouble();
                                                    boolean coordYModificada = controller.modificarCoordenadaYDePuntoDeInteres(
                                                            nombreEvidenciaModificarPunto, nombrePuntoModificar, nuevaCoordenadaY
                                                    );
                                                    if (coordYModificada) {
                                                        System.out.println("Coordenada Y modificada correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar la coordenada Y del punto de interés. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                case 3:
                                                    System.out.println("Ingrese el nuevo contenido del código único del punto de interés:");
                                                    String nuevoContenidoCodigoUnico = scanner.nextLine();
                                                    boolean codigoUnicoModificado = controller.modificarCodigoUnicoDePuntoDeInteres(
                                                            nombreEvidenciaModificarPunto, nombrePuntoModificar, nuevoContenidoCodigoUnico
                                                    );
                                                    if (codigoUnicoModificado) {
                                                        System.out.println("Código único modificado correctamente.");
                                                    } else {
                                                        System.out.println("Hubo un error al modificar el código único del punto de interés. Por favor, inténtelo de nuevo.");
                                                    }
                                                    break;
                                                default:
                                                    System.out.println("Opción no válida.");
                                            }
                                        case 9:
                                            System.out.println("Ingrese el nombre de la evidencia a la cual desea eliminar un punto de interés:");
                                            String nombreEvidenciaEliminarPunto = scanner.nextLine();

                                            System.out.println("Ingrese el nombre del punto de interés que desea eliminar:");
                                            String nombrePuntoEliminar = scanner.nextLine();

                                            boolean puntoEliminado = controller.eliminarPuntoDeInteres(nombreEvidenciaEliminarPunto, nombrePuntoEliminar);

                                            if (puntoEliminado) {
                                                System.out.println("Punto de interés '" + nombrePuntoEliminar + "' eliminado correctamente de la evidencia.");
                                            } else {
                                                System.out.println("Hubo un error al eliminar el punto de interés. Por favor, inténtelo de nuevo.");
                                            }
                                            break;
                                        case 10:
                                            System.out.println("Lista de Reseñas en Estado de Espera:");

                                            System.out.println("Ingrese el nombre de la reseña que desea aprobar/rechazar:");
                                            String nombreResena = scanner.nextLine();

                                            System.out.println("Ingrese el nombre del proyecto al que pertenece la reseña:");
                                            String nombreProyectoResena = scanner.nextLine();

                                            boolean resenaAprobada = controller.aprobarRechazarResena(nombreResena, nombreProyectoResena);

                                            if (resenaAprobada) {
                                                System.out.println("Reseña aprobada correctamente.");
                                            } else {
                                                System.out.println("Hubo un error al aprobar/rechazar la reseña. Por favor, inténtelo de nuevo.");
                                            }
                                            break;

                                        case 11:
                                            System.out.println("Ingrese el nombre del proyecto del cual desea ver la información detallada:");
                                            String nombreProyectoDetalle = scanner.nextLine();
                                            String informacionDetalleProyecto = controller.consultarInformacionDetalladaProyecto(nombreProyectoDetalle);
                                            System.out.println(informacionDetalleProyecto);
                                            break;
                                        case 12:
                                            System.out.println("Ingrese el nombre del proyecto del cual desea ver las evidencias asociadas:");
                                            String nombreProyectoEvidencias = scanner.nextLine();
                                            String informacionEvidenciasProyecto = controller.consultarEvidenciasAsociadasProyecto(nombreProyectoEvidencias);
                                            System.out.println(informacionEvidenciasProyecto);
                                            break;
                                        case 13:
                                            System.out.println("Saliendo del menú de Investigador. ¡Hasta luego!");
                                            break;

                                        default:
                                            System.out.println("Opción no válida.");
                                            break;
                                    }
                                default:
                                    System.out.println("¡Gracias por usar nuestra aplicación! ¡Hasta luego!");
                                    break;
                            }
                        } else {
                            System.out.println("Error al obtener el tipo de usuario.");
                        }
                    } else {
                        System.out.println("Error de autenticación. Usuario o contraseña incorrectos.");
                    }
                    break;
                case 3:
                    controller.generarObjetosDePrueba();
                    break;
                case 4:
                    System.out.println("Ingrese el número del pilar (1. Biodiversidad, 2. Gestión del recurso hídrico, 3. Gestión integral de residuos sólidos, 4. Energía):");
                    int numeroPilarUsuario = scanner.nextInt();
                    scanner.nextLine();

                    String nombrePilarUsuario = controller.obtenerNombrePilarPorNumero(numeroPilarUsuario);

                    if (!nombrePilarUsuario.isEmpty()) {
                        String informacionPilarYProyectos = controller.obtenerInformacionPilarYProyectos(nombrePilarUsuario);

                        System.out.println(java.util.Objects.requireNonNullElse(informacionPilarYProyectos, "El pilar no fue encontrado o no tiene proyectos asociados."));
                    } else {
                        System.out.println("Número de pilar no válido. Inténtelo de nuevo.");
                    }
                    break;
                case 5:
                    System.out.println("Ingrese el nombre del proyecto:");
                    scanner.nextLine();
                    String nombreProyectoConsulta = scanner.nextLine().trim();

                    System.out.println("Nombre del proyecto a consultar: " + nombreProyectoConsulta);

                    if (!nombreProyectoConsulta.isEmpty()) {
                        String informacionDetallada = controller.consultarInformacionDetalladaProyecto(nombreProyectoConsulta);
                        System.out.println(informacionDetallada);
                    } else {
                        System.out.println("Nombre de proyecto no válido. Inténtelo de nuevo.");
                    }
                    break;
                case 6:
                    System.out.println("Simulador");
                    String tipoUsuarioSimulador = scanner.nextLine();

                    switch (tipoUsuarioSimulador.toLowerCase()) {
                        case "visitante":

                            System.out.println("Ingrese el pilar:");
                            String pilarConsultar = scanner.nextLine();

                            System.out.println("Ingrese el proyecto:");
                            String proyectoConsultar = scanner.nextLine();

                            controller.consultarMapaGeneralPuntosInteres(pilarConsultar, proyectoConsultar);

                            System.out.println("Ingrese el nombre de la evidencia para consultar información detallada:");
                            String nombreEvidenciaConsultar = scanner.nextLine();

                            controller.consultarInformacionDetalladaEvidencia(nombreEvidenciaConsultar);

                            System.out.println("Ingrese el nombre de la evidencia a la cual desea agregar un comentario:");
                            String nombreEvidenciaComentario = scanner.nextLine();

                            System.out.println("Ingrese el nombre del punto de interés al que desea agregar un comentario:");
                            String nombrePuntoComentario = scanner.nextLine();

                            System.out.println("Ingrese el comentario:");
                            String comentario = scanner.nextLine();

                            boolean comentarioRegistrado = controller.registrarComentarioPuntoInteres(
                                    nombreEvidenciaComentario, nombrePuntoComentario, comentario);

                            if (comentarioRegistrado) {
                                System.out.println("Comentario registrado correctamente.");
                            } else {
                                System.out.println("Hubo un error al registrar el comentario. Por favor, inténtelo de nuevo.");
                            }
                            break;
                        case "recolector":
                            System.out.println("Ingrese el nombre del proyecto al que desea agregar una reseña:");
                            String nombreProyectoResena = scanner.nextLine();

                            System.out.println("Ingrese la reseña:");
                            String contenidoResena = scanner.nextLine();

                            boolean resenaRegistrada = controller.registrarResenaEvidenciaProyecto(nombreProyectoResena, contenidoResena);

                            if (resenaRegistrada) {
                                System.out.println("Reseña registrada correctamente como evidencia al proyecto.");
                            } else {
                                System.out.println("Hubo un error al registrar la reseña. Por favor, inténtelo de nuevo.");
                            }

                            System.out.println("1. Consultar Puntos de Interés");
                            System.out.println("2. Consultar Información de Proyectos");
                            System.out.println("3. Consultar Información de Evidencias relacionadas con un Punto de Interés");
                            System.out.println("4. Visualizar Detalles de un Punto de Interés");
                            System.out.println("5. Hacer Comentarios en un Punto de Interés");

                            int opcionVisitante = scanner.nextInt();
                            scanner.nextLine();

                            switch (opcionVisitante) {
                                case 1:
                                    controller.mostrarListaPuntosDeInteres();
                                    break;
                                case 2:
                                    controller.mostrarListaProyectos();
                                    break;
                                case 3:
                                    System.out.println("Ingrese el nombre del Punto de Interés:");
                                    String nombrePuntoInteres = scanner.nextLine();
                                    controller.mostrarEvidenciasRelacionadasConPunto(nombrePuntoInteres);
                                    break;
                                case 4:
                                    System.out.println("Ingrese el nombre del Punto de Interés:");
                                    String nombrePuntoDetalle = scanner.nextLine();
                                    controller.mostrarDetallesPuntoDeInteres(nombrePuntoDetalle);
                                    break;
                                case 5:
                                    System.out.println("Ingrese el nombre del Punto de Interés:");
                                    String nombrePuntoComentarioSimulador = scanner.nextLine();
                                    System.out.println("Ingrese su comentario:");
                                    String comentarioSimulador = scanner.nextLine();
                                    controller.registrarComentarioEnPunto(nombrePuntoComentarioSimulador, comentarioSimulador);
                                    break;
                                default:
                                    System.out.println("Opción no válida.");
                                    break;
                            }
                            break;
                        case "investigador":
                            System.out.println("Ingrese el nombre del proyecto del cual desea consultar información detallada:");
                            String nombreProyectoInvestigador = scanner.nextLine();
                            controller.consultarInformacionDetalladaProyecto(nombreProyectoInvestigador);

                            System.out.println("Ingrese el nombre del nuevo proyecto:");
                            String nombreNuevoProyecto = scanner.nextLine();

                            System.out.println("Ingrese a qué pilar pertenece el proyecto:");
                            System.out.println("(1. Biodiversidad, 2. Gestion del recurso hídrico, 3. Gestion integral de residuos solidos, 4. Energia ");
                            int numeroPilar = Integer.parseInt(scanner.nextLine());

                            System.out.println("¿Es un proyecto activo? (Sí/No):");
                            boolean proyectoActivo = scanner.nextLine().equalsIgnoreCase("Sí");

                            System.out.println("Ingrese el ID del proyecto:");
                            String idProyecto = scanner.nextLine();

                            System.out.println("Ingrese la descripción del proyecto:");
                            String descripcionProyecto = scanner.nextLine();

                            System.out.println("Ingrese la fecha de inicio del proyecto (Formato: dd/mm/yyyy):");
                            String fechaInicioProyecto = scanner.nextLine();

                            System.out.println("Ingrese la fecha de fin del proyecto (Formato: dd/mm/yyyy):");
                            String fechaFinProyecto = scanner.nextLine();

                            boolean proyectoCreado = controller.registrarProyecto(
                                    idProyecto, nombreNuevoProyecto, descripcionProyecto,
                                    fechaInicioProyecto, fechaFinProyecto, String.valueOf(proyectoActivo), numeroPilar
                            );

                            if (proyectoCreado) {
                                System.out.println("Nuevo proyecto creado con éxito.");
                            } else {
                                System.out.println("Hubo un error al crear el proyecto. Por favor, inténtelo de nuevo.");
                            }

                            System.out.println("Ingrese el nombre del proyecto que desea modificar:");
                            String nombreProyectoModificar = scanner.nextLine();
                            System.out.println("Ingrese la nueva descripción del proyecto:");
                            String nuevaDescripcionModificar = scanner.nextLine();
                            boolean proyectoModificado = controller.modificarProyecto(nombreProyectoModificar, nuevaDescripcionModificar);

                            if (proyectoModificado) {
                                System.out.println("Proyecto modificado correctamente.");
                            } else {
                                System.out.println("Hubo un error al modificar el proyecto. Por favor, inténtelo de nuevo.");
                            }

                            System.out.println("Ingrese el nombre de la nueva evidencia:");
                            String nuevoNombreEvidencia = scanner.nextLine();
                            System.out.println("Ingrese la descripción de la nueva evidencia:");
                            String nuevaDescripcionEvidencia = scanner.nextLine();
                            boolean evidenciaRegistrada = controller.registrarEvidencia(nuevoNombreEvidencia, nombreProyectoInvestigador, nuevaDescripcionEvidencia);

                            if (evidenciaRegistrada) {
                                System.out.println("Nueva evidencia registrada correctamente.");
                            } else {
                                System.out.println("Hubo un error al registrar la nueva evidencia. Por favor, inténtelo de nuevo.");
                            }

                            System.out.println("Ingrese el nombre de la evidencia que desea modificar:");
                            String nombreEvidenciaModificarInvestigador = scanner.nextLine();
                            System.out.println("Ingrese la nueva descripción de la evidencia:");
                            String nuevaDescripcionModificarInvestigador = scanner.nextLine();
                            boolean evidenciaModificada = controller.modificarEvidencia(nombreEvidenciaModificarInvestigador, nuevaDescripcionModificarInvestigador);

                            if (evidenciaModificada) {
                                System.out.println("Evidencia modificada correctamente.");
                            } else {
                                System.out.println("Hubo un error al modificar la evidencia. Por favor, inténtelo de nuevo.");
                            }

                            System.out.println("Ingrese el nombre de la evidencia que contiene la reseña:");
                            String nombreEvidenciaResena = scanner.nextLine();
                            System.out.println("Ingrese la reseña que desea revisar y cambiar de estado:");
                            String contenidoResenaInvestigador = scanner.nextLine();
                            boolean estadoResenaCambiado = controller.cambiarEstadoResena(nombreEvidenciaResena, contenidoResenaInvestigador);

                            if (estadoResenaCambiado) {
                                System.out.println("Estado de la reseña cambiado correctamente.");
                            } else {
                                System.out.println("Hubo un error al cambiar el estado de la reseña. Por favor, inténtelo de nuevo.");
                            }

                            System.out.println("1. Consultar Puntos de Interés");
                            System.out.println("2. Consultar Información de Proyectos");
                            System.out.println("3. Consultar Información de Evidencias relacionadas con un Punto de Interés");
                            System.out.println("4. Visualizar Detalles de un Punto de Interés");
                            System.out.println("5. Hacer Comentarios en un Punto de Interés");

                            System.out.println("Ingrese el número correspondiente a la opción deseada:");
                            int opcionInvestigador = scanner.nextInt();
                            scanner.nextLine();

                            switch (opcionInvestigador) {
                                case 1:
                                    controller.mostrarListaPuntosDeInteres();
                                    break;
                                case 2:
                                    controller.mostrarListaProyectos();
                                    break;
                                case 3:
                                    System.out.println("Ingrese el nombre del Punto de Interés:");
                                    String nombrePuntoInteres = scanner.nextLine();
                                    controller.mostrarEvidenciasRelacionadasConPunto(nombrePuntoInteres);
                                    break;
                                case 4:
                                    System.out.println("Ingrese el nombre del Punto de Interés:");
                                    String nombrePuntoDetalle = scanner.nextLine();
                                    controller.mostrarDetallesPuntoDeInteres(nombrePuntoDetalle);
                                    break;
                                case 5:
                                    System.out.println("Ingrese el nombre del Punto de Interés:");
                                    String nombrePuntoComentarioSimulador = scanner.nextLine();
                                    System.out.println("Ingrese su comentario:");
                                    String comentarioSimulador = scanner.nextLine();
                                    controller.registrarComentarioEnPunto(nombrePuntoComentarioSimulador, comentarioSimulador);
                                    break;
                                default:
                                    System.out.println("Opción no válida.");
                            }
                            break;
                    }
                    break;
                case 7:
                    System.out.println("Saliendo del sistema...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intenta de nuevo.");
            }
        }
    }
}


