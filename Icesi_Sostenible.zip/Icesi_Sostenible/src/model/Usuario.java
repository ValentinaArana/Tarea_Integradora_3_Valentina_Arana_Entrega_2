package model;

import java.util.List;

public class Usuario {
    private String nombreUsuario;
    private String contrasena;
    private String nombre;

    public Usuario(String nombreUsuario, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public String getNombre() {
        return this.nombre;
    }
}
