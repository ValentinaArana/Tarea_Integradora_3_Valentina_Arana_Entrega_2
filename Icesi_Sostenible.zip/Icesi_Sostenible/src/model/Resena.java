package model;

public class Resena {
    private String contenidoDeLaResena;
    private String estado;
    private String fechaActual;
    private String descripcion;

    public Resena(String contenidoDeLaResena, String estado, String fechaActual, String descripcion) {
        this.contenidoDeLaResena = contenidoDeLaResena;
        this.estado = estado;
        this.fechaActual = fechaActual;
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void cambiarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
    }
}
