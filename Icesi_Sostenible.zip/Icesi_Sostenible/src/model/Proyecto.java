package model;

import java.util.ArrayList;
import java.util.List;

public class Proyecto {
    private String nombrePilar;
    private String nombreProyecto;
    private String idProyecto;
    private String idPilar;
    private String descripcion;
    private String fechaInicio;
    private String fechaFin;
    private String estado;
    private List<Evidencia> evidencias;
    private List<Resena> resenasPendientes;

    public Proyecto(String idProyecto, String nombreProyecto, String descripcion, String fechaInicio, String fechaFin, String estado, String nombrePilar) {
        this.idProyecto = idProyecto;
        this.nombrePilar = nombrePilar;
        this.nombreProyecto = nombreProyecto;
        this.descripcion = descripcion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.evidencias = new ArrayList<>();
        this.resenasPendientes = new ArrayList<>();
    }

    public String getNombre() {
        return this.nombreProyecto;
    }

    public String getNombreProyecto() {
        return nombreProyecto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Evidencia> getEvidencias() {
        return evidencias;
    }

    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void agregarEvidencia(Evidencia evidencia) {
        evidencias.add(evidencia);
    }

    public String getNombrePilar() {
        return nombrePilar;
    }

    public String getIdProyecto() {
        return idProyecto;
    }

    public Evidencia buscarEvidenciaPorNombre(String nombreEvidencia) {
        for (Evidencia evidencia : evidencias) {
            if (evidencia.getNombre().equals(nombreEvidencia)) {
                return evidencia;
            }
        }
        return null;
    }

    public void agregarResenaPendiente(Resena resena) {
        resenasPendientes.add(resena);
    }

    public Resena buscarResenaPorNombre(String nombreResena) {
        for (Resena resena : resenasPendientes) {
            if (resena.getDescripcion().equals(nombreResena)) {
                return resena;
            }
        }
        return null;
    }
}
