package model;

public class Visitante extends Usuario {

    public Visitante(String nombreUsuario, String contrasena) {
        super(nombreUsuario, contrasena);
    }
}