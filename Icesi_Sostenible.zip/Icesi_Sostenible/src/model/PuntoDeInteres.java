package model;

import java.util.ArrayList;
import java.util.List;

public class PuntoDeInteres {
    private String nombre;
    private String descripcion;
    public String codigoQR;
    private double coordenadaX;
    private double coordenadaY;
    public Evidencia evidencia;
    public String tipo;
    private List<String> comentarios;

    public PuntoDeInteres(String nombre, String descripcion, String codigoQR, double coordenadaX, double coordenadaY) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.codigoQR = codigoQR;
        this.coordenadaX = coordenadaX;
        this.coordenadaY = coordenadaY;
        this.comentarios = new ArrayList<>();
    }

    public String getNombre() {
        return this.nombre;
    }

    public double getCoordenadaX() {
        return coordenadaX;
    }

    public double getCoordenadaY() {
        return coordenadaY;
    }

    public void setCodigoQR(String codigoQR) {
        this.codigoQR = codigoQR;
    }

    public void setCoordenadaX(double coordenadaX) {
        this.coordenadaX = coordenadaX;
    }

    public void setCoordenadaY(double coordenadaY) {
        this.coordenadaY = coordenadaY;
    }

    public String getDescripcion() {
        return this.descripcion;
    }

    public Evidencia getEvidencia() {
        return this.evidencia;
    }

    public String getTipo() {
        return tipo;
    }

    public void agregarComentario(String comentario) {
        comentarios.add(comentario);
    }
}
