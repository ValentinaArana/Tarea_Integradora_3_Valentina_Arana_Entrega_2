package model;

public class Investigador extends Usuario{
    public Investigador(String nombreUsuario, String contrasena, String nombreInvestigador, String correoInvestigador, String telefonoInvestigador, String areaInvestigador, String cargoInvestigador) {
        super(nombreUsuario, contrasena);
    }
}
