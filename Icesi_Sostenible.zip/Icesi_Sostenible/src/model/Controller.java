package model;

import java.text.ParseException;
import java.util.UUID;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.util.stream.Collectors;

public class Controller {
    private List<Resena> listaResenas = new ArrayList<>();
    private List<Proyecto> listaProyectos;
    private Map<Integer, Proyecto> mapaProyectos;
    private Map<Integer, Proyecto> proyectos;
    private List<PuntoDeInteres> puntosDeInteres;
    private List<Evidencia> evidencias;
    private List<Usuario> listaUsuarios;
    private List<Resena> listaDeEvidencias;
    private List<PuntoDeInteres> listaPuntosDeInteres;
    private List<Evidencia> listaEvidencias;
    private List<Usuario> usuariosVisitantes;
    private Map<String, Pilar> pilares;
    private Scanner scanner = new Scanner(System.in);

    public Controller() {

        listaUsuarios = new ArrayList<>();
        listaDeEvidencias = new ArrayList<>();
        listaPuntosDeInteres = new ArrayList<>();
        listaEvidencias = new ArrayList<>();
        usuariosVisitantes = new ArrayList<>();
        puntosDeInteres = new ArrayList<>();
        pilares = new HashMap<>();
        proyectos = new HashMap<>();
        listaProyectos = new ArrayList<>();
        mapaProyectos = new HashMap<>();
    }
    public boolean registrarInvestigador(String nombreUsuario, String contrasena, String nombreInvestigador, String correoInvestigador, String telefonoInvestigador, String areaInvestigador, String cargoInvestigador) {
        Investigador investigador = new Investigador(nombreUsuario, contrasena, nombreInvestigador, correoInvestigador, telefonoInvestigador, areaInvestigador, cargoInvestigador);
        return listaUsuarios.add(investigador);
    }

    public boolean registrarRecolector(String nombreUsuario, String contrasena, String nombreRecolector, String correoRecolector, String telefonoRecolector) {
        Recolector recolector = new Recolector(nombreUsuario, contrasena, nombreRecolector, correoRecolector, telefonoRecolector);
        return listaUsuarios.add(recolector);
    }

    public boolean registrarVisitante(String nombreUsuario, String contrasena) {
        try {
            Visitante nuevoVisitante = new Visitante(nombreUsuario, contrasena);
            listaUsuarios.add(nuevoVisitante);
            return true;
        } catch (Exception e) {
            System.out.println("Hubo un error al registrar el visitante. Por favor, inténtelo de nuevo.");
            return false;
        }
    }

    public String consultarInformacionDetalladaProyecto(String nombreProyecto) {
        Proyecto proyectoConsultado = this.obtenerProyectoPorNombre(nombreProyecto);

        if (proyectoConsultado != null) {
            int cantidadEvidenciasResena = this.contarEvidenciasPorTipo(nombreProyecto, "Reseña");
            int cantidadEvidenciasOtrosTipos = this.contarEvidenciasOtrosTipos(nombreProyecto);

            return "Cantidad de Evidencias de Tipo Reseña: " + cantidadEvidenciasResena +
                    "\nCantidad de Evidencias de Otros Tipos: " + cantidadEvidenciasOtrosTipos;
        } else {
            return "El proyecto no fue encontrado.";
        }
    }
    public void generarObjetosDePrueba() throws ParseException {
        Usuario usuarioVisitante = new Usuario("visitante", "contrasenaVisitante");
        this.registrarUsuario(usuarioVisitante);

        Usuario usuarioRecolector = new Usuario("recolector", "contrasenaRecolector");
        this.registrarUsuario(usuarioRecolector);

        Usuario usuarioInvestigador = new Usuario("investigador", "contrasenaInvestigador");
        this.registrarUsuario(usuarioInvestigador);

        for (int i = 1; i <= 4; i++) {
            String nombrePilar = obtenerNombrePilar(i);

            Date fechaInicio = new Date();
            Date fechaFin = new Date(System.currentTimeMillis() + 100000);

            this.registrarProyecto("ID" + i, "Proyecto de Prueba " + nombrePilar, "Descripción de prueba", fechaInicio.toString(), fechaFin.toString(), "Activo", i);
        }

        String nombreProyecto = null;
        for (int i = 1; i <= 4; i++) {
            nombreProyecto = "Proyecto de Prueba " + obtenerNombrePilar(i);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            String fechaActual = dateFormat.format(new Date());

            Evidencia evidenciaTexto = new Evidencia("Texto de prueba", "https://ruta/a/texto.txt", nombreProyecto, fechaActual, "Texto");
            this.registrarEvidencia(evidenciaTexto);

            Evidencia evidenciaImagen = new Evidencia("Imagen de prueba", "https://ruta/a/imagen.jpg", nombreProyecto, fechaActual, "Imagen");
            this.registrarEvidencia(evidenciaImagen);

            Evidencia evidenciaAudio = new Evidencia("Audio de prueba", "https://ruta/a/audio.mp3", nombreProyecto, fechaActual, "Audio");
            this.registrarEvidencia(evidenciaAudio);

            Evidencia evidenciaVideo = new Evidencia("Video de prueba", "https://ruta/a/video.mp4", nombreProyecto, fechaActual, "Video");
            this.registrarEvidencia(evidenciaVideo);

            Evidencia evidenciaResena = new Evidencia("Reseña de prueba", "https://ruta/a/resena.txt", nombreProyecto, fechaActual, "Reseña");
            this.registrarEvidencia(evidenciaResena);

            Evidencia evidenciaInforme = new Evidencia("Informe de resultados de prueba", "https://ruta/a/informe.pdf", nombreProyecto, fechaActual, "Informe de Resultados");
            this.registrarEvidencia(evidenciaInforme);
        }

        PuntoDeInteres puntoPrueba = new PuntoDeInteres("Nombre del Punto de Interés", "Descripción del punto", "CódigoQR123", 10.5, 20.3);
        this.registrarPuntoDeInteres(puntoPrueba);

        List<Evidencia> evidenciasProyecto = obtenerEvidenciasPorProyecto(nombreProyecto);

        if (!evidenciasProyecto.isEmpty()) {
            Evidencia evidenciaAsociada = evidenciasProyecto.get(0);
            evidenciaAsociada.agregarPuntoDeInteres(puntoPrueba);
            System.out.println("Se ha asociado el punto de interés a la evidencia.");
        } else {
            System.out.println("No hay evidencias asociadas al proyecto para vincular el punto de interés.");
        }

        System.out.println("Se han generado objetos de prueba en el sistema.");

    }

    public List<Evidencia> obtenerEvidenciasPorProyecto(String nombreProyecto) {
        List<Evidencia> evidenciasProyecto = new ArrayList<>();

        List<Proyecto> proyectos = obtenerProyectos();
        
        Proyecto proyectoEncontrado = null;
        for (Proyecto proyecto : proyectos) {
            if (proyecto.getNombre().equals(nombreProyecto)) {
                proyectoEncontrado = proyecto;
                break;
            }
        }
        
        if (proyectoEncontrado != null) {
            evidenciasProyecto = proyectoEncontrado.getEvidencias();
        }

        return evidenciasProyecto;
    }

    private List<Proyecto> obtenerProyectos() {

        List<Proyecto> proyectos = new ArrayList<>();

        proyectos.add(new Proyecto("ID1", "Proyecto 1", "Descripción 1", "FechaInicio1", "FechaFin1", "Activo", "NombrePilar1"));
        proyectos.add(new Proyecto("ID2", "Proyecto 2", "Descripción 2", "FechaInicio2", "FechaFin2", "Activo", "NombrePilar2"));
        proyectos.add(new Proyecto("ID3", "Proyecto 3", "Descripción 3", "FechaInicio3", "FechaFin3", "Activo", "NombrePilar3"));

        return proyectos;
    }

    private void registrarPuntoDeInteres(PuntoDeInteres puntoPrueba) {
        Evidencia evidencia = puntoPrueba.getEvidencia();

        if (evidencia != null) {
            evidencia.agregarPuntoDeInteres(puntoPrueba);
            System.out.println("Punto de interés registrado con éxito.");
        } else {
            System.out.println("No se encontró la evidencia asociada. No se ha registrado el punto de interés.");
        }
    }


    private void registrarResena(Resena resenaPrueba) {
        try {
            listaResenas.add(resenaPrueba);

            System.out.println("Reseña registrada con éxito.");
        } catch (Exception e) {
            System.out.println("Hubo un error al registrar la reseña. Por favor, inténtelo de nuevo.");
        }
    }


    public boolean registrarProyecto(String idProyecto, String nombreProyecto, String descripcion, String fechaInicio, String fechaFin, String estado, int numeroPilar) {
        try {
            String nombrePilar = obtenerNombrePilar(numeroPilar);

            Proyecto nuevoProyecto = new Proyecto(idProyecto, nombreProyecto, descripcion, fechaInicio, fechaFin, estado, nombrePilar);

            listaProyectos.add(nuevoProyecto);

            mapaProyectos.put(listaProyectos.size() - 1, nuevoProyecto);

            return true;
        } catch (Exception e) {
            System.out.println("Hubo un error al registrar el proyecto. Por favor, inténtelo de nuevo.");
            return false;
        }
    }

    private String obtenerNombrePilar(int numeroPilar) {
        switch (numeroPilar) {
            case 1:
                return "Biodiversidad";
            case 2:
                return "Gestion del recurso hídrico";
            case 3:
                return "Gestion integral de residuos solidos";
            case 4:
                return "Energia";
            default:
                return "Pilar no reconocido";
        }
    }

    public String obtenerInformacionPilarYProyectos(String nombrePilar) {
        List<Proyecto> proyectosAsociados = listaProyectos.stream()
                .filter(proyecto -> nombrePilar.equals(proyecto.getNombrePilar()))
                .collect(Collectors.toList());

        StringBuilder informacion = new StringBuilder();
        informacion.append("Información del pilar ").append(nombrePilar).append(":\n");

        if (!proyectosAsociados.isEmpty()) {
            informacion.append("Proyectos asociados:\n");
            proyectosAsociados.forEach(proyecto -> {
                informacion.append("- ").append(proyecto.getNombreProyecto()).append(" (Asociado al pilar ").append(proyecto.getNombrePilar()).append(")\n");
            });
        } else {
            informacion.append("No se encontraron proyectos asociados al pilar ").append(nombrePilar).append(".");
        }

        return informacion.toString();
    }

    public String obtenerNombrePilarPorNumero(int numeroPilar) {
        switch (numeroPilar) {
            case 1:
                return "Biodiversidad";
            case 2:
                return "Gestión del recurso hídrico";
            case 3:
                return "Gestión integral de residuos sólidos";
            case 4:
                return "Energía";
            default:
                return "";
        }
    }

    public void registrarUsuario(Usuario usuarioPrueba) {
        listaUsuarios.add(usuarioPrueba);
        System.out.println("Se registró un nuevo usuario ");
    }

    private void registrarEvidencia(Evidencia evidenciaPrueba) {
        try {
            if (!listaEvidencias.contains(evidenciaPrueba)) {
                listaEvidencias.add(evidenciaPrueba);
                System.out.println("Se registró una nueva evidencia ");
            } else {
                System.out.println("La evidencia ya existe en el sistema.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error al registrar la evidencia. Por favor, inténtelo de nuevo.");
        }
    }

    public Evidencia buscarEvidenciaPorNombre(String nombreEvidencia) {
        for (Evidencia evidencia : evidencias) {
            if (evidencia.getNombreDescriptivo().equals(nombreEvidencia)) {
                return evidencia;
            }
        }
        return null;
    }

    private Proyecto obtenerProyectoPorNombre(String nombreProyecto) {
        for (Proyecto proyecto : listaProyectos) {
            if (proyecto.getNombreProyecto().equals(nombreProyecto)) {
                return proyecto;
            }
        }
        return null;
    }

    private int contarEvidenciasOtrosTipos(String nombreProyecto) {
        int contador = 0;
        for (Evidencia evidencia : listaEvidencias) {
            if (!evidencia.getTipo().equals("TipoEspecifico")) {
                contador++;
            }
        }
        return contador;
    }

    private int contarEvidenciasPorTipo(String nombreProyecto, String tipoEvidencia) {
        int contador = 0;
        for (Evidencia evidencia : listaEvidencias) {
            if (evidencia.getTipo().equals(tipoEvidencia)) {
                contador++;
            }
        }
        return contador;
    }

    public String generarCodigoUnico() {
        String uuid = UUID.randomUUID().toString();
        String codigoUnico = "MI_APP_" + uuid;
        return codigoUnico;
    }

    public boolean registrarEvidencia(String nombreEvidencia, String nombreProyecto, String tipoEvidencia, boolean tienePuntoInteres, String urlEvidencia, String descripcionDetallada, String fechaRegistroEvidencia) throws ParseException {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyecto);

        if (proyecto != null) {
            Evidencia nuevaEvidencia = new Evidencia(nombreEvidencia, descripcionDetallada, nombreProyecto, fechaRegistroEvidencia, tipoEvidencia);

            nuevaEvidencia.setUrl(urlEvidencia);

            if (tienePuntoInteres) {
                System.out.println("Ingrese la coordenada X del punto de interés:");
                double coordenadaX = scanner.nextDouble();

                System.out.println("Ingrese la coordenada Y del punto de interés:");
                double coordenadaY = scanner.nextDouble();
                scanner.nextLine();

                System.out.println("Ingrese el nombre del punto de interés:");
                String nombrePuntoInteres = scanner.nextLine();

                System.out.println("Ingrese la descripción del punto de interés:");
                String descripcionPuntoInteres = scanner.nextLine();

                System.out.println("Ingrese el código QR del punto de interés:");
                String codigoQRPuntoInteres = scanner.nextLine();

                PuntoDeInteres nuevoPuntoDeInteres = new PuntoDeInteres(nombrePuntoInteres, descripcionPuntoInteres, codigoQRPuntoInteres, coordenadaX, coordenadaY);

                nuevaEvidencia.agregarPuntoDeInteres(nuevoPuntoDeInteres);
            }

            proyecto.agregarEvidencia(nuevaEvidencia);
            listaEvidencias.add(nuevaEvidencia);

            return true;
        } else {
            System.out.println("El proyecto especificado no existe. No se ha registrado la evidencia.");
            return false;
        }
    }

    private Proyecto buscarProyectoPorNombre(String nombreProyecto) {
        for (Proyecto proyecto : listaProyectos) {
            if (proyecto.getNombreProyecto().equals(nombreProyecto)) {
                return proyecto;
            }
        }
        return null;
    }
    public boolean registrarResena(String nombreResena, String descripcionResena, String nombreProyectoAsociado) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fechaActual = dateFormat.format(new Date());

        Proyecto proyectoAsociado = buscarProyectoPorNombre(nombreProyectoAsociado);
        if (proyectoAsociado != null) {
            Resena nuevaResena = new Resena(nombreResena, descripcionResena, "Pendiente de aprobación", fechaActual);
            proyectoAsociado.agregarResenaPendiente(nuevaResena);
            return true;
        } else {
            System.out.println("El proyecto asociado no fue encontrado.");
            return false;
        }
    }

    public boolean eliminarEvidencia(String nombreEvidenciaEliminar) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaEliminar);

        if (evidencia != null) {
            eliminarEvidencia(evidencia);
            return true;
        } else {
            return false;
        }
    }

    private void eliminarEvidencia(Evidencia evidencia) {
        Iterator<Evidencia> iterator = listaEvidencias.iterator();
        while (iterator.hasNext()) {
            Evidencia actual = iterator.next();
            if (actual.equals(evidencia)) {
                iterator.remove();
                break;
            }
        }
    }

    public boolean modificarEvidencia(String nombreEvidenciaModificar, String nuevoNombreDescriptivo) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificar);

        if (evidencia != null) {
            evidencia.setNombreDescriptivo(nuevoNombreDescriptivo);
            return true;
        } else {
            return false;
        }
    }

    public boolean agregarPuntoDeInteresAEvidencia(String nombreEvidencia, String nombrePunto, int coordenadaX, int coordenadaY, String descripcionPunto) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidencia);

        if (evidencia != null) {
            PuntoDeInteres nuevoPunto = new PuntoDeInteres(nombrePunto, descripcionPunto, "codigoQR", 0.0, 0.0);
            evidencia.agregarPuntoDeInteres(nuevoPunto);
            return true;
        } else {
            return false;
        }
    }

    public boolean autenticarUsuario(String nombreUsuario, String contrasena) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.getNombreUsuario().trim().equals(nombreUsuario) && usuario.getContrasena().equals(contrasena)) {
                return true;
            }
        }
        return false;
    }

    public String obtenerTipoUsuario(String nombreUsuarioEncontrar) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.getNombreUsuario().equals(nombreUsuarioEncontrar)) {
                if (usuario instanceof Investigador) {
                    System.out.println("Es un Investigador");
                    return "Investigador";
                } else if (usuario instanceof Recolector) {
                    System.out.println("Es un Recolector");
                    return "Recolector";
                } else {
                    System.out.println("Es un Visitante");
                    return "Visitante";
                }
            }
        }
        return null;
    }

    public void mostrarListaPuntosDeInteres() {
        List<PuntoDeInteres> puntosDeInteres = obtenerListaPuntosDeInteres();

        if (puntosDeInteres.isEmpty()) {
            System.out.println("No hay puntos de interés disponibles.");
        } else {
            System.out.println("Lista de Puntos de Interés:");
            for (PuntoDeInteres punto : puntosDeInteres) {
                System.out.println("Nombre: " + punto.getNombre() + ", Descripción: " + punto.getDescripcion());
            }
        }
    }

    public void mostrarListaProyectos() {
        List<Proyecto> proyectos = obtenerListaProyectos();

        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos disponibles.");
        } else {
            System.out.println("Lista de Proyectos:");
            for (Proyecto proyecto : proyectos) {
                System.out.println("Nombre: " + proyecto.getNombre() + ", Descripción: " + proyecto.getDescripcion());
            }
        }
    }

    public void mostrarEvidenciasRelacionadasConPunto(String nombrePuntoInteres) {
        List<Evidencia> evidenciasRelacionadas = obtenerEvidenciasRelacionadasConPunto(nombrePuntoInteres);

        if (evidenciasRelacionadas.isEmpty()) {
            System.out.println("No hay evidencias relacionadas con el punto de interés.");
        } else {
            System.out.println("Evidencias Relacionadas con el Punto de Interés:");
            for (Evidencia evidencia : evidenciasRelacionadas) {
                System.out.println("Nombre: " + evidencia.getNombre() + ", Tipo: " + evidencia.getTipo());
            }
        }
    }

    public void mostrarDetallesPuntoDeInteres(String nombrePuntoDetalle) {
        PuntoDeInteres puntoDetalle = obtenerDetallesPuntoDeInteres(nombrePuntoDetalle);

        if (puntoDetalle != null) {
            System.out.println("Detalles del Punto de Interés:");
            System.out.println("Nombre: " + puntoDetalle.getNombre());
            System.out.println("Descripción: " + puntoDetalle.getDescripcion());
        } else {
            System.out.println("El punto de interés no fue encontrado.");
        }
    }

    public boolean registrarComentarioEnPunto(String nombrePuntoComentario, String comentario) {
        boolean comentarioRegistrado = registrarComentarioEnPunto(nombrePuntoComentario, comentario);

        if (comentarioRegistrado) {
            System.out.println("Comentario registrado correctamente.");
        } else {
            System.out.println("Hubo un error al registrar el comentario. Por favor, inténtelo de nuevo.");
        }
        return comentarioRegistrado;
    }

    public boolean aprobarRechazarEvidencia(String nombreEvidencia, String nombreProyecto) {
        boolean evidenciaAprobadaRechazada = aprobarRechazarEvidenciaLogica(nombreEvidencia, nombreProyecto);

        if (evidenciaAprobadaRechazada) {
            System.out.println("Evidencia aprobada/rechazada correctamente.");
        } else {
            System.out.println("Hubo un error al aprobar/rechazar la evidencia. Por favor, inténtelo de nuevo.");
        }

        return evidenciaAprobadaRechazada;
    }


    private boolean aprobarRechazarEvidenciaLogica(String nombreEvidencia, String nombreProyecto) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyecto);

        if (proyecto != null) {
            Evidencia evidencia = proyecto.buscarEvidenciaPorNombre(nombreEvidencia);

            if (evidencia != null) {
                if (cumpleCriteriosAprobacion(evidencia)) {
                    evidencia.cambiarEstado("Aprobada");
                    notificarUsuariosAprobacion(evidencia);
                    return true;
                } else {
                    evidencia.cambiarEstado("Rechazada");
                    notificarUsuariosRechazo(evidencia);
                    return true;
                }
            } else {
                System.out.println("La evidencia no fue encontrada en el proyecto.");
                return false;
            }
        } else {
            System.out.println("El proyecto no fue encontrado.");
            return false;
        }
    }
    private void notificarUsuariosRechazo(Evidencia evidencia) {
        System.out.println("Evidencia rechazada: " + evidencia.getNombre());
    }

    private void notificarUsuariosAprobacion(Evidencia evidencia) {
    }

    private boolean cumpleCriteriosAprobacion(Evidencia evidencia) {
        List<PuntoDeInteres> puntosDeInteres = evidencia.getPuntosDeInteres();
        return !puntosDeInteres.isEmpty();
    }


    public String consultarEvidenciasAsociadasProyecto(String nombreProyectoEvidencias) {
        List<Evidencia> evidenciasAsociadas = obtenerEvidenciasAsociadasProyecto(nombreProyectoEvidencias);

        if (evidenciasAsociadas.isEmpty()) {
            return "No hay evidencias asociadas al proyecto.";
        } else {
            StringBuilder resultado = new StringBuilder();
            resultado.append("Evidencias Asociadas al Proyecto:\n");
            for (Evidencia evidencia : evidenciasAsociadas) {
                resultado.append("Nombre: ").append(evidencia.getNombre()).append(", Tipo: ").append(evidencia.getTipo()).append("\n");
            }
            return resultado.toString();
        }
    }
    public List<PuntoDeInteres> obtenerListaPuntosDeInteres() {
        return puntosDeInteres;
    }

    public List<Evidencia> obtenerEvidenciasRelacionadasConPunto(String nombrePuntoInteres) {
        List<Evidencia> evidenciasRelacionadas = new ArrayList<>();

        for (Evidencia evidencia : evidencias) {
            if (evidencia.getPuntoDeInteres().getNombre().equals(nombrePuntoInteres)) {
                evidenciasRelacionadas.add(evidencia);
            }
        }

        return evidenciasRelacionadas;
    }

    public PuntoDeInteres obtenerDetallesPuntoDeInteres(String nombrePuntoDetalle) {
        for (PuntoDeInteres punto : puntosDeInteres) {
            if (punto.getNombre().equals(nombrePuntoDetalle)) {
                return punto;
            }
        }

        return null;
    }

    public List<Evidencia> obtenerEvidenciasAsociadasProyecto(String nombreProyectoEvidencias) {
        List<Evidencia> evidenciasAsociadas = new ArrayList<>();

        for (Proyecto proyecto : mapaProyectos.values()) {
            if (proyecto.getNombre().equals(nombreProyectoEvidencias)) {
                evidenciasAsociadas.addAll(proyecto.getEvidencias());
            }
        }

        return evidenciasAsociadas;
    }

    public List<Proyecto> obtenerListaProyectos() {
        return new ArrayList<>(mapaProyectos.values());
    }

    public boolean eliminarProyecto(String nombreProyectoEliminar) {
        Proyecto proyectoAEliminar = buscarProyectoPorNombre(nombreProyectoEliminar);

        if (proyectoAEliminar != null) {
            listaProyectos.remove(proyectoAEliminar);
            proyectos.remove(proyectoAEliminar.getIdProyecto());
            return true;
        } else {
            System.out.println("El proyecto no fue encontrado. No se pudo eliminar.");
            return false;
        }
    }

    public boolean modificarNombreProyecto(String nombreProyectoModificar, String nuevoNombreProyecto) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoModificar);

        if (proyecto != null) {
            proyecto.setNombreProyecto(nuevoNombreProyecto);
            return true;
        } else {
            System.out.println("El proyecto no fue encontrado.");
            return false;
        }
    }

    public boolean modificarDescripcionProyecto(String nombreProyectoModificarDesc, String nuevaDescripcionProyecto) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoModificarDesc);

        if (proyecto != null) {
            proyecto.setDescripcion(nuevaDescripcionProyecto);
            return true;
        } else {
            System.out.println("El proyecto no fue encontrado.");
            return false;
        }
    }

    public boolean modificarFechaInicioProyecto(String nombreProyectoModificarFechaInicio, String nuevaFechaInicio) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoModificarFechaInicio);

        if (proyecto != null) {
            proyecto.setFechaInicio(nuevaFechaInicio);
            return true;
        } else {
            System.out.println("El proyecto no fue encontrado.");
            return false;
        }
    }
    public boolean modificarFechaFinProyecto(String nombreProyectoModificarFechaFin, String nuevaFechaFin) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoModificarFechaFin);

        if (proyecto != null) {
            proyecto.setFechaFin(nuevaFechaFin);
            return true;
        } else {
            return false;
        }
    }

    public boolean activarProyecto(String nombreProyectoActivar) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoActivar);

        if (proyecto != null) {
            proyecto.setEstado("Activo");
            return true;
        } else {
            return false;
        }
    }

    public boolean desactivarProyecto(String nombreProyectoDesactivar) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoDesactivar);

        if (proyecto != null) {
            proyecto.setEstado("Inactivo");
            return true;
        } else {
            return false;
        }
    }

    public boolean modificarNombreDescriptivoEvidencia(String nombreEvidenciaModificar, String nuevoNombreDescriptivo) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificar);

        if (evidencia != null) {
            evidencia.setNombreDescriptivo(nuevoNombreDescriptivo);
            return true;
        } else {
            return false;
        }
    }

    public boolean modificarTipoEvidencia(String nombreEvidenciaModificar, String nuevoTipoEvidencia) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificar);

        if (evidencia != null) {
            evidencia.setTipo(nuevoTipoEvidencia);
            return true;
        } else {
            return false;
        }
    }

    public boolean modificarDescripcionDetalladaEvidencia(String nombreEvidenciaModificar, String nuevaDescripcionDetallada) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificar);

        if (evidencia != null) {
            evidencia.setDescripcionDetallada(nuevaDescripcionDetallada);
            return true;
        } else {
            return false;
        }
    }

    public boolean modificarURLEvidencia(String nombreEvidenciaModificar, String nuevaURL) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificar);

        if (evidencia != null) {
            evidencia.setUrl(nuevaURL);
            return true;
        } else {
            return false;
        }
    }

    public int generarCoordenadaAleatoria() {
        return (int) (Math.random() * 100);
    }

    public boolean modificarCoordenadaXDePuntoDeInteres(String nombreEvidenciaModificarPunto, String nombrePuntoModificar, double nuevaCoordenadaX) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificarPunto);

        if (evidencia != null) {
            PuntoDeInteres punto = buscarPuntoDeInteresEnEvidencia(evidencia, nombrePuntoModificar);

            if (punto != null) {
                punto.setCoordenadaX(nuevaCoordenadaX);
                return true;
            } else {
                System.out.println("El punto de interés especificado no existe en la evidencia.");
                return false;
            }
        } else {
            System.out.println("La evidencia especificada no existe.");
            return false;
        }
    }

    private PuntoDeInteres buscarPuntoDeInteresEnEvidencia(Evidencia evidencia, String nombrePuntoModificar) {
        if (evidencia != null) {
            List<PuntoDeInteres> puntosDeInteres = evidencia.getPuntosDeInteres();

            for (PuntoDeInteres punto : puntosDeInteres) {
                if (punto.getNombre().equals(nombrePuntoModificar)) {
                    return punto;
                }
            }

            System.out.println("El punto de interés especificado no existe en la evidencia.");
            return null;
        } else {
            System.out.println("La evidencia proporcionada es nula.");
            return null;
        }
    }

    public boolean modificarCoordenadaYDePuntoDeInteres(String nombreEvidenciaModificarPunto, String nombrePuntoModificar, double nuevaCoordenadaY) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificarPunto);

        if (evidencia != null) {
            PuntoDeInteres punto = buscarPuntoDeInteresEnEvidencia(evidencia, nombrePuntoModificar);

            if (punto != null) {
                punto.setCoordenadaY(nuevaCoordenadaY);
                return true;
            } else {
                System.out.println("El punto de interés especificado no existe en la evidencia.");
                return false;
            }
        } else {
            System.out.println("La evidencia especificada no existe.");
            return false;
        }
    }

    public boolean modificarCodigoUnicoDePuntoDeInteres(String nombreEvidenciaModificarPunto, String nombrePuntoModificar, String nuevoContenidoCodigoUnico) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaModificarPunto);

        if (evidencia != null) {
            PuntoDeInteres punto = buscarPuntoDeInteresEnEvidencia(evidencia, nombrePuntoModificar);

            if (punto != null) {
                punto.setCodigoQR(nuevoContenidoCodigoUnico);
                return true;
            } else {
                System.out.println("El punto de interés especificado no existe en la evidencia.");
                return false;
            }
        } else {
            System.out.println("La evidencia especificada no existe.");
            return false;
        }
    }

    public boolean eliminarPuntoDeInteres(String nombreEvidenciaEliminarPunto, String nombrePuntoEliminar) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaEliminarPunto);

        if (evidencia != null) {
            boolean puntoEliminado = evidencia.eliminarPuntoDeInteres(nombrePuntoEliminar);

            if (puntoEliminado) {
                listaPuntosDeInteres.removeIf(punto -> punto.getNombre().equals(nombrePuntoEliminar));
            }

            return puntoEliminado;
        } else {
            System.out.println("La evidencia especificada no existe. No se ha eliminado el punto de interés.");
            return false;
        }
    }

    public void consultarMapaGeneralPuntosInteres(String pilarConsultar, String proyectoConsultar) {

        List<PuntoDeInteres> puntos = obtenerMapaGeneralPuntosInteres(pilarConsultar, proyectoConsultar);

        System.out.println("Mapa General de Puntos de Interés:");

        for (PuntoDeInteres punto : puntos) {
            System.out.println("Símbolo: " + obtenerSimboloEvidencia(punto.getTipo()) +
                    " - Coordenadas: (" + punto.getCoordenadaX() + ", " + punto.getCoordenadaY() + ")");
        }
    }

    private List<PuntoDeInteres> obtenerMapaGeneralPuntosInteres(String pilarConsultar, String proyectoConsultar) {

        List<PuntoDeInteres> puntosDeInteres = new ArrayList<>();

        List<Evidencia> evidencias = obtenerEvidenciasPorPilarYProyecto(pilarConsultar, proyectoConsultar);
        for (Evidencia evidencia : evidencias) {
            puntosDeInteres.addAll(evidencia.getPuntosDeInteres());
        }

        return puntosDeInteres;
    }

    private List<Evidencia> obtenerEvidenciasPorPilarYProyecto(String pilar, String proyecto) {

        List<Evidencia> evidencias = new ArrayList<>();

        for (Evidencia evidencia : listaEvidencias) {
            if (evidencia.getPilarAsociado().getNombre().equals(pilar)
                    && evidencia.getProyectoAsociado().equals(proyecto)) {
                evidencias.add(evidencia);
            }
        }
        return evidencias;
    }

    private String obtenerSimboloEvidencia(String tipoEvidencia) {

        switch (tipoEvidencia) {
            case "Imagen":
                return "F";
            case "Video":
                return "V";
            case "Reseña":
                return "R";
            case "Audio":
                return "A";
            case "Texto":
                return "T";
            case " Informes":
                return "I";
            default:
                return "?";
        }
    }

    public void consultarInformacionDetalladaEvidencia(String nombreEvidenciaConsultar) {

        Evidencia evidencia = obtenerInformacionDetalladaEvidencia(nombreEvidenciaConsultar);

        if (evidencia != null) {
            System.out.println("Información detallada de la evidencia " + nombreEvidenciaConsultar + ":");
            System.out.println("Nombre Descriptivo: " + evidencia.getNombreDescriptivo());
            System.out.println("Proyecto Asociado: " + evidencia.getProyectoAsociado());
            System.out.println("Fecha de Registro: " + evidencia.getFechaRegistro());
            System.out.println("Descripción Detallada: " + evidencia.getDescripcionDetallada());
            System.out.println("Tipo de Evidencia: " + evidencia.getTipo());
            System.out.println("URL: " + evidencia.getUrl());

            List<PuntoDeInteres> puntosDeInteres = evidencia.getPuntosDeInteres();
            System.out.println("Puntos de Interés Asociados:");
            for (PuntoDeInteres punto : puntosDeInteres) {
                System.out.println("Coordenadas: (" + punto.getCoordenadaX() + ", " + punto.getCoordenadaY() + ")");
            }
        } else {
            System.out.println("No se encontró la evidencia con nombre " + nombreEvidenciaConsultar);
        }
    }

    private Evidencia obtenerInformacionDetalladaEvidencia(String nombreEvidenciaConsultar) {
        for (Evidencia evidencia : listaEvidencias) {
            if (evidencia.getNombreDescriptivo().equals(nombreEvidenciaConsultar)) {
                return evidencia;
            }
        }
        return null;
    }

    public boolean registrarComentarioPuntoInteres(String nombreEvidenciaComentario, String nombrePuntoComentario, String comentario) {
        Evidencia evidencia = buscarEvidenciaPorNombre(nombreEvidenciaComentario);

        if (evidencia != null) {
            PuntoDeInteres punto = buscarPuntoDeInteresEnEvidencia(evidencia, nombrePuntoComentario);

            if (punto != null) {
                punto.agregarComentario(comentario);
                System.out.println("Comentario registrado correctamente en el punto de interés.");
                return true;
            } else {
                System.out.println("El punto de interés especificado no existe en la evidencia.");
            }
        } else {
            System.out.println("La evidencia especificada no existe.");
        }
        return false;
    }

    public boolean registrarResenaEvidenciaProyecto(String nombreProyectoResena, String contenidoResena) throws ParseException {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoResena);

        if (proyecto != null) {
            Evidencia nuevaResena = new Evidencia("Reseña", contenidoResena, nombreProyectoResena, obtenerFechaActual(), "Reseña");
            proyecto.agregarEvidencia(nuevaResena);
            listaEvidencias.add(nuevaResena);

            System.out.println("Reseña registrada correctamente como evidencia al proyecto.");
            return true;
        } else {
            System.out.println("El proyecto especificado no existe.");
            return false;
        }
    }

    public boolean modificarProyecto(String nombreProyectoModificar, String nuevaDescripcionModificar) {
        Proyecto proyectoModificar = buscarProyectoPorNombre(nombreProyectoModificar);

        if (proyectoModificar != null) {
            proyectoModificar.setDescripcion(nuevaDescripcionModificar);
            System.out.println("Proyecto modificado correctamente: " + nombreProyectoModificar);
            return true;
        } else {
            System.out.println("El proyecto especificado no existe. No se ha modificado el proyecto.");
            return false;
        }
    }

    public boolean registrarEvidencia(String nuevoNombreEvidencia, String nombreProyectoInvestigador, String nuevaDescripcionEvidencia) throws ParseException {
        Proyecto proyectoInvestigador = buscarProyectoPorNombre(nombreProyectoInvestigador);

        if (proyectoInvestigador != null) {
            Evidencia nuevaEvidencia = new Evidencia(nuevoNombreEvidencia, nuevaDescripcionEvidencia, nombreProyectoInvestigador, obtenerFechaActual(), "TipoEjemplo");

            proyectoInvestigador.agregarEvidencia(nuevaEvidencia);
            listaEvidencias.add(nuevaEvidencia);

            System.out.println("Evidencia registrada correctamente en el proyecto: " + nombreProyectoInvestigador);
            return true;
        } else {
            System.out.println("El proyecto especificado no existe. No se ha registrado la evidencia.");
            return false;
        }
    }

    public boolean cambiarEstadoResena(String nombreEvidenciaResena, String contenidoResenaInvestigador) {
        Evidencia evidenciaResena = buscarEvidenciaPorNombre(nombreEvidenciaResena);

        if (evidenciaResena != null) {
            evidenciaResena.cambiarEstado(contenidoResenaInvestigador);

            return true;
        } else {
            System.out.println("La evidencia especificada no existe. No se ha cambiado el estado.");
            return false;
        }
    }

    private String obtenerFechaActual() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date fechaActual = new Date();
        return dateFormat.format(fechaActual);
    }

    public boolean aprobarRechazarResena(String nombreResena, String nombreProyectoResena) {
        Proyecto proyecto = buscarProyectoPorNombre(nombreProyectoResena);

        if (proyecto != null) {
            Resena resena = proyecto.buscarResenaPorNombre(nombreResena);

            if (resena != null) {
                resena.cambiarEstado("Aprobada");
                notificarUsuariosAprobacionResena(resena);
                return true;
            } else {
                System.out.println("La reseña no fue encontrada en el proyecto.");
                return false;
            }
        } else {
            System.out.println("El proyecto no fue encontrado.");
            return false;
        }
    }

    private void notificarUsuariosAprobacionResena(Resena resena) {
        System.out.println("Reseña aprobada: " + resena.getDescripcion());
    }
}
