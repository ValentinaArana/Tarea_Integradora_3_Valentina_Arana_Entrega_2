package model;

import java.util.ArrayList;
import java.util.List;

public class Pilar {
    public String nombre;
    public String descripcion;
    public List<Proyecto> proyectosAsociados;
    public String nombreDescriptivo;

    public Pilar(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.proyectosAsociados = new ArrayList<>();
    }

    public String getNombre() {
        return this.nombreDescriptivo;
    }

}