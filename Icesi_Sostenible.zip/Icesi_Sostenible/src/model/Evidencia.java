package model;

import java.util.ArrayList;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Evidencia {

    private List<PuntoDeInteres> puntosDeInteres;
    private String proyectoAsociado;
    private Date fechaRegistro;
    private String nombreDescriptivo;
    private String descripcionDetallada;
    private String tipo;
    private String url;
    public PuntoDeInteres puntoDeInteres;
    public Pilar pilarAsociado;

    public Evidencia(String nombreDescriptivo, String descripcionDetallada, String proyectoAsociado, String fechaRegistro, String tipo) throws ParseException {
        this.nombreDescriptivo = nombreDescriptivo;
        this.descripcionDetallada = descripcionDetallada;
        this.proyectoAsociado = proyectoAsociado;
        this.tipo = tipo;

        this.puntosDeInteres = new ArrayList<>();

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date fechaRegistroEvidencia = dateFormat.parse("18-11-2023");

        try {
            this.fechaRegistro = dateFormat.parse(fechaRegistro);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public String getNombreDescriptivo() {
        return nombreDescriptivo;
    }

    public String getProyectoAsociado() {
        return proyectoAsociado;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public String getDescripcionDetallada() {
        return descripcionDetallada;
    }

    public void setDescripcionDetallada(String nuevaDescripcionDetallada) {
        this.descripcionDetallada = nuevaDescripcionDetallada;
    }

    public void setNombreDescriptivo(String nuevoNombreDescriptivo) {
        this.nombreDescriptivo = nuevoNombreDescriptivo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getNombre() {
        return "NombreDelObjeto";
    }

    public PuntoDeInteres getPuntoDeInteres() {
        return this.puntoDeInteres;
    }
    public void agregarPuntoDeInteres(PuntoDeInteres punto) {
        puntosDeInteres.add(punto);
    }
    public List<PuntoDeInteres> getPuntosDeInteres() {
        return puntosDeInteres;
    }

    public void setUrl(String nuevaURL) {
        if (nuevaURL != null && !nuevaURL.isEmpty()) {
            this.url = nuevaURL;
            System.out.println("URL actualizada con éxito: " + this.url);
        } else {
            System.out.println("La URL proporcionada es nula o vacía. No se ha actualizado la URL.");
        }
    }
    public String getUrl() {
        return url;
    }

    public void setTipo(String nuevoTipoEvidencia) {
        if (nuevoTipoEvidencia != null && !nuevoTipoEvidencia.isEmpty()) {
            this.tipo = nuevoTipoEvidencia;
            System.out.println("Tipo de evidencia actualizado con éxito: " + this.tipo);
        } else {
            System.out.println("El tipo de evidencia proporcionado es nulo o vacío. No se ha actualizado el tipo de evidencia.");
        }
    }

    public boolean eliminarPuntoDeInteres(String nombrePuntoEliminar) {
        PuntoDeInteres puntoEliminar = null;

        for (PuntoDeInteres punto : puntosDeInteres) {
            if (punto.getNombre().equals(nombrePuntoEliminar)) {
                puntoEliminar = punto;
                break;
            }
        }

        if (puntoEliminar != null) {
            puntosDeInteres.remove(puntoEliminar);
            System.out.println("Punto de interés eliminado correctamente.");
            return true;
        } else {
            System.out.println("El punto de interés especificado no existe en la evidencia.");
            return false;
        }
    }

    public Pilar getPilarAsociado() {
        return this.pilarAsociado;
    }

    public void cambiarEstado(String nuevoEstado) {
        System.out.println("Estado cambiado en la evidencia: " + nuevoEstado);
    }
}
